package com.example.demo;

public interface HelloWorldRMI
{
    public String sayHelloRmi(String msg);
}