# Googol

Neste projeto foi-nos pedido que desenvolvêssemos um motor de pesquisa de paginas Web que reunisse um conjunto de funcionalidades parecidas a serviços conhecidos do dia a dia (Google, Bing, Duckduckgo).


## Manual de Instalação

O nosso projeto foi desenvolvido num ambiente criado pelo `IntelliJ IDEA`.
Sendo assim, para melhor compatibilidade, aconcelhamos a instalar o software.

Aqui segue-se o manual de instalação do [IntelliJ](https://www.jetbrains.com/help/idea/installation-guide.html#205c2633).

Em acrescimo, usamos a libraria [Jsoup](https://jsoup.org/) no nosso projeto,
pelo que existe a necessidade de acrescentar esta dependência.

Para adicionar dependências ao projeto, uma possibilidade é usar o `Maven`, que vem por default instalado. Em todo o caso, deixamos aqui o [link](https://www.jetbrains.com/help/idea/maven-support.html) direto para a documentação de instalação.

Para que esteja tudo compativel com as versões que foram utilizadas segue o nosso ficheiro `pom.xml` que deve ser adicionado na diretoria:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>org.example</groupId>
    <artifactId>untitled</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.jsoup</groupId>
            <artifactId>jsoup</artifactId>
            <version>1.15.4</version>
        </dependency>
    </dependencies>

    <build>
        <sourceDirectory>src/Download/java</sourceDirectory>
    </build>
</project>
``` 
Utilizando o `IntelliJ IDEA` basta importar a pasta `Googol` disponibilizada, sendo assim possivel compilar e executar sem dificuldades, podendo ter de definir esta pasta como source root.


## Manual de Utilização

Para podermos correr o nosso projeto há alguns pontos a ter em conta.

O nosso programa `Storage Barrel` recebe como parametro o nome de um ficheiro. Para isso, clicar com o botão esquerdo na classe > More Run/Debug > Modify Run Configuration: escrever o nome do ficheiro em Program Arguments.

Para que se possa correr multiplas vezes este programa, na mesma aba > Modify Options > Ativar: Allow Multiple Instances.

Agora estamos prontos para correr o projeto.
Para isso começamos por correr o DownloadServer > SearchModule > StorageBarrel > Client.
